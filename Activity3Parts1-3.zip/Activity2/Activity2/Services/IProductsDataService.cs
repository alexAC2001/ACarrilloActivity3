﻿using Activity2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Activity2.Services
{
    public interface IProductsDataService
    {
        /*List<MovieModel> AllProducts();
        List<MovieModel> SearchProducts(string searchTerm);
        MovieModel GetProductById(int id);
        int Insert(MovieModel product);
        bool Delete(MovieModel product);
        int Update(MovieModel product);
        */
        List<ProductModel> AllProducts();
        List<ProductModel> SearchProducts(string searchTerm);
        ProductModel GetProductById(int id);
        int Insert(ProductModel product);
        bool Delete(ProductModel product);
        int Update(ProductModel product);
        
    }
}
