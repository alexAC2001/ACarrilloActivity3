﻿using ButtonGrid.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ButtonGrid.Controllers
{
    public class ButtonController : Controller
    {
        // create a list of buttons
        static List<ButtonModel> buttons = new List<ButtonModel>();
        Random random = new Random();
        const int GRID_SIZE = 25;

        public IActionResult Index()
        {
            // empty the list when the page loads
            buttons = new List<ButtonModel>();

            // Generate some new buttons. Randomly chosen color values
            for(int i = 0; i < GRID_SIZE; i++)
            {
                buttons.Add(new ButtonModel(i, random.Next(4)));
            }
            /*// when the page loads, generate some new buttons. Randomly chosen values
            buttons.Add(new ButtonModel(0, 0));
            buttons.Add(new ButtonModel(1, 3));
            buttons.Add(new ButtonModel(2, 0));
            buttons.Add(new ButtonModel(3, 1));
            buttons.Add(new ButtonModel(4, 2));
            */
            // send the button list to the "Index" page
            return View("Index", buttons);
        }

        public IActionResult HandleButtonClick(string buttonNumber)
        {
            // convert from string to int
            int bN = int.Parse(buttonNumber);
            // add one to the button state. If greater than 4, reset to 0
            buttons.ElementAt(bN).ButtonState = ( buttons.ElementAt(bN).ButtonState + 1 ) % 4;

           /* if(buttons.ButtonState == 2)
            {
                return View("Success");
            }*/

            // re-display the buttons
            return View("Index", buttons);
        }
    }
}
